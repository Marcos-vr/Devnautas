<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href=" https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css" integrity="sha512-1PKOgIY59xJ8Co8+NE6FZ+LOAZKjy+KY8iq0G4B3CyeY6wYHN3yt9PW0XpSriVlkMXe40PTKnXrLnZ9+fkDaog==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<footer class="bg-dark text-white pt-5 pb-4">

    <div class="container text-center text-md-left">

        <div class="row text-center text-md-left">

            <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">

                <h5 class="text-uppercase mb-4 font-weight-bold text-warning">Devnautas</h5>
                <p>Devnautas é uma empresa de programação inovadora e ágil, especializada em oferecer soluções de software personalizadas e de alto desempenho.</p>

            </div>

            <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">

                <h5 class="text-uppercase mb-4 font-weight-bold text-warning">Produtos</h5>

                <p>
                    <a href="#" class="text-white" style="text-decoration: none;"> Petabyte</a>
                </p>

                <p>
                    <a href="#" class="text-white" style="text-decoration: none;"> Devnautas</a>
                </p>

                <p>
                    <a href="#" class="text-white" style="text-decoration: none;"> Locadora</a>
                </p>
                

            </div>

            <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">

                <h5 class="text-uppercase mb-4 font-weight-bold text-warning">Sobre</h5>

                <p>
                    <a href="#" class="text-white" data-bs-toggle="modal" data-bs-target="#sobreNos" style="text-decoration: none;"> Sobre nos</a>
                </p>

                <p>
                    <a href="#" class="text-white" style="text-decoration: none;"> Criadores</a>
                </p>

                <p>
                    <a href="#" class="text-white" style="text-decoration: none;"> Desenvolvedores</a>
                </p>

            </div>

            <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">

                <h5 class="text-uppercase mb-4 font-weight-bold text-warning">Contatos</h5>

                <p>
                    <i class="fas fa-home mr-3"></i> Governador Valadares ,BRA
                </p>

                <p>
                    <i class="fas fa-envelope mr-3"></i> Contato@gmail.com.br
                </p>

                <p>
                    <i class="fas fa-phone mr-3"></i> 33 984238065
                </p>

                <p>
                    <i class="fas fa-phone mr-3"></i> 33 984263972
                </p>

            </div>

        </div>

        <hr class="mb-4">

        <div class="row align-items-center">

            <div class="col-md-7 col-lg-8 ">

                <p>copyright ©2024 Todos os direitos são reservados pela Empresa

                <a href="#" style="text-decoration: none;">

                    <strong class="text-warning">Devnautas</strong>

                    </p></a>

            </div>

            <div class="col-md-5 col-lg-4">

                <div class="text-center text-md-right">

                    <ul class="list-unstyled list-inline">

                        <li class="list-inline-item">

                            <a href="https://www.facebook.com/" class="btn-floating btn-sm text-white fab fa-facebook linha" style="font-size: 17px"></a>

                        </li>

                        <li class="list-inline-item">

                            <a href="https://www.twitter.com/" class="btn-floating btn-sm text-white fab fa-twitter linha" style="font-size: 17px"></a>

                        </li>

                        <li class="list-inline-item">

                            <a href="https://www.google.com/" class="btn-floating btn-sm text-white fab fa-google-plus linha" style="font-size: 17px"></a>

                        </li>

                        <li class="list-inline-item">

                            <a href="https://www.linkedin.com/" class="btn-floating btn-sm text-white fab fa-linkedin-in linha" style="font-size: 17px"></a>

                        </li>

                        <li class="list-inline-item">

                            <a href="https://www.github.com/" class="btn-floating btn-sm text-white fab fa-github linha" style="font-size: 17px "></a>

                        </li>

                    </ul>

                </div>

            </div>

        </div>

    </div>

    <!-- Modal sobre Nos -->
    <div class="modal fade" id="sobreNos" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5 text-dark" id="exampleModalLabel">Devnautas</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-dark">
                    <strong>

                     Fundada por apaixonados por tecnologia em 2024, a Devnautas tem como missão principal impulsionar o sucesso de seus clientes por meio de soluções digitais sob medida.

                    Trabalhamos em estreita colaboração com nossos clientes para entender suas necessidades específicas e oferecer soluções que não apenas atendam, mas excedam suas expectativas.

                    Na Devnautas, abraçamos as últimas tecnologias e metodologias de desenvolvimento, para garantir que nossos projetos sejam entregues com eficiência e qualidade. Além do desenvolvimento de software, oferecemos consultoria em estratégia de tecnologia, integração de sistemas, migração para nuvem e muito mais.

                    Nosso portfólio diversificado abrange uma ampla gama de setores, incluindo fintech, saúde, educação, comércio eletrônico e além. Independentemente do tamanho ou complexidade do projeto, estamos comprometidos em fornecer soluções sob medida que impulsionam o crescimento e a inovação dos negócios de nossos clientes.

                    Se você está procurando uma equipe de desenvolvimento confiável e dedicada para colaborar em seu próximo projeto de tecnologia, entre em contato com a Devnautas hoje mesmo. Estamos prontos para embarcar em sua jornada digital e ajudá-lo a alcançar novos patamares de sucesso.

                    </strong>
                </div>
                <div class="modal-footer mb-4">
                </div>
            </div>
        </div>
    </div>

</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>



</html>
