<?php
function listarTabela($campos,$tabela, $campoOrdem)
{
    $conn = conectar();
    try {
        $conn->beginTransaction();
        $sqlLista = $conn->prepare("SELECT $campos FROM $tabela ORDER BY $campoOrdem ");
//        $sqlLista->bindValue(1, $campoParametro, PDO::PARAM_INT);
        $sqlLista->execute();
        $conn->commit();
        if ($sqlLista->rowCount() > 0) {
            return $sqlLista->fetchAll(PDO::FETCH_OBJ);
        } else {
            return 'Vazio';
        };
    } 
    catch
    (PDOExecption $e) {
        echo 'Exception -> ';
        return ($e->getMessage());
        $conn->rollback();
    };
    $conn = null;
}


function validarsenha($campos, $tabela, $campobdstring, $campobdstring2, $campoparametro, $campoparametro2, $campobdativo, $valorativo)
{
    $conn = conectar();
    try {
        $conn ->begintransaction();
        $sqlLista = $conn ->prepare("SELECT $campos "
            . " FROM $tabela "
            . "WHERE $campobdstring = ? AND $campobdstring2 = ? AND $campobdativo = ? ");
        $sqlLista->bindValue(1, $campoparametro, PDO::PARAM_STR);
        $sqlLista->bindValue(2, $campoparametro2, PDO::PARAM_STR);
        $sqlLista->bindValue(3, $valorativo, PDO::PARAM_STR);
        $sqlLista->execute(); 
        $conn->commit();

        if ($sqlLista->rowCount() > 0) {
            return $sqlLista->fetchAll(PDO::FETCH_OBJ);
        } else {
            return "Vazio";
        }
    } catch (Throwable $e) {
        $error_message = 'Throwable:' . $e->getMessage() . PHP_EOL;
        $error_message = 'File:' . $e->getFile() . PHP_EOL;
        $error_message = 'Line:' . $e->getFile() . PHP_EOL;
        error_log($error_message, 3, 'arquivo_log.txt');
        $conn->rollBack();
        throw $e;
    };
}




function insert($tabela, $campo, $value1){
    $conn = conectar();
    try{
        $conn->beginTransaction();
        $sqlInsert = $conn->prepare("INSERT INTO $tabela($campo) VALUES(?)");
        $sqlInsert->bindValue(1, $value1, PDO::PARAM_STR);
        $sqlInsert->execute();
        $conn->commit();
        if ($sqlInsert->rowCount() > 0){
            return true;
        } else {
            return null;;
        };
    } 
    catch(PDOException $e) {
        echo 'Exeception ->';
        return ($e->getMessage());
        $conn->rollBack();
    };
    $conn = null;
  }

  function editum($tabela, $campo, $campoId, $valorupdate, $valorid){
    $conn = conectar();
    try {
        $conn ->beginTransaction();
        $sqlLista = $conn->prepare("UPDATE $tabela SET $campo = ? WHERE $campoId = ?");
        $sqlLista->bindValue(1, $valorupdate, PDO::PARAM_STR);
        $sqlLista->bindValue(2, $valorid, PDO::PARAM_INT);
        $sqlLista->execute();
        $conn->commit();
        if ($sqlLista->rowCount() > 0) {
            return 1;
        } else {
            return true;
        }
        return null;

    } catch (Throwable $e) {
       
    };

}

function excluir($tabela, $campo, $id){
    $conn = conectar();
    try {
        $conn ->beginTransaction();
        $sqlExcluir = $conn->prepare("DELETE FROM $tabela WHERE $campo = ?");
        $sqlExcluir->bindValue(1, $id, PDO::PARAM_STR);
        $sqlExcluir->execute();
        $conn->commit();

        if ($sqlExcluir->rowCount() > 0) {
            return true;
        } else {
            return null;
        }
        

    } catch (PDOException $e) {
        echo 'Exception ->';
        return ($e->getMessage());
        $conn->rollBack();
       
    }
    $conn=null;
}

function insertdois($tabela, $campo1, $campo2, $value1, $value2){
    $conn = conectar();
    try{
        $conn->beginTransaction();
        $sqlInsert = $conn->prepare("INSERT INTO $tabela($campo1,$campo2) VALUES(?,?)");
        $sqlInsert->bindValue(1, $value1, PDO::PARAM_STR);
        $sqlInsert->bindValue(2, $value2, PDO::PARAM_STR);
        $sqlInsert->execute();
        $conn->commit();
        if ($sqlInsert->rowCount() > 0){
            return true;
        } else {
            return null;;
        };
    } 
    catch(PDOException $e) {
        echo 'Exeception ->';
        return ($e->getMessage());
        $conn->rollBack();
    };
    $conn = null;
}

?>