if (document.getElementById('cpf')) {
    document.getElementById('email').focus();
  }
  
  function fazerLogin() {
    var email = document.getElementById("email").value;
    var senha = document.getElementById("senha").value;
    var alertlog = document.getElementById("alertlog");
  
    if (email === '') {
      alertlog.style.display = 'block';
      alertlog.innerHTML = 'O campo de e-mail está vazio. Por favor, preencha o e-mail.';
      return;
    } else if (senha === '') {
      alertlog.style.display = 'block';
      alertlog.innerHTML = 'O campo de senha está vazio. Por favor, preencha a senha.';
      return;
    } else if (senha.length < 8) {
      alertlog.style.display = 'block';
      alertlog.innerHTML = 'Senha inválida. Mínimo de 8 ou mais digitos.';
      return;
    } else {
      alertlog.style.display = 'none';
    }
    // mostrarProcessando();
    fetch('conf.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: 'email=' + encodeURIComponent(email) + '&senha=' + encodeURIComponent(senha),
    })
      .then(response => response.json())
      .then(data => {
        console.log(data);
        esconderProcessando();
        if (data.success) {
          window.location.href = "adm.php";
          alert(data.message);
          alertlog.classList.remove('alert-danger');
          alertlog.classList.add('alert-success');
          alertlog.innerHTML = data.message;
          alertlog.style.display = 'block';
        } else {
          alertlog.style.display = 'block';
          alertlog.innerHTML = data.message;
        }
      })
      .catch(error => {
        console.error("Erro na requisição", error);
      });
  }
  // CRIANDO PROCESSANDO 
  function mostrarProcessando() {
    var divProcessando = document.createElement('div');
    divProcessando.id = 'processandoDiv';
    divProcessando.style.position = 'fixed';
    divProcessando.style.top = '40%';
    divProcessando.style.left = '50%';
    divProcessando.style.transform = 'translate(-50%, -50%)';
    divProcessando.innerHTML = '<img src="img/loading4.gif" width="250px" alt="Processando..." title="Processando...">';
    document.body.appendChild(divProcessando);
  }
  
  function esconderProcessando() {
    var divProcessando = document.getElementById('processandoDiv');
    if (divProcessando) {
      document.body.removeChild(divProcessando);
    }
  }


function carregarConteudo(controle) {
    fetch('controle.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: 'controle=' + encodeURIComponent(controle),
    })
      .then(response => response.text())
      .then(data => {
        document.getElementById('show').innerHTML = data;
        document.getElementById('show').innerHTML = data;
      })
      .catch(error => console.error('Erro na requisição:', error));
  };

  function excluirGeral(lista,controle,id){
    fetch('controle.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: 'controle=' + encodeURIComponent(controle) + '&id=' + encodeURIComponent(id)
    })
      .then(response => response.json())
      .then(data => {
        console.log(data)
        if (data.success){
          alert(data.message);
          carregarConteudo(lista);
  
        } else {
          alert(data.message);
        }
      })
      
      .catch(error => console.error('Erro na requisição:', error));
  }

  const clienteModalFechar = new bootstrap.Modal(
    document.getElementById('cadCliente')
  );
  const modalcliente = document.getElementById('cadCliente');
  const inputcliente = document.getElementById('idCLiente');
  const inputcpf = document.getElementById('idCPF');
  const btnAddcliente = document.getElementById('btnAddcliente');
  
  
  if (modalcliente) {
    const formCategoria = document.getElementById("frmCadCliente");
  
    modalcliente.addEventListener('shown.bs.modal', () => {
      inputcliente.focus();
  
      const submitHandler = function (event) {
        event.preventDefault();
        btnAddcliente.disabled = true;
        mostrarProcessando();
  
        var form = event.target;
        var formData = new FormData(form);
        formData.append('controle', 'clienteadd');
  
        fetch('controle.php', {
          method: "POST",
          body: formData,
        })
          .then((response) => response.json())
          .then((data) => {
            console.log(data);
            if (data.success) {
              form.reset();
              form.removeEventListener("submit", submitHandler);
              btnAddcliente.disabled = false;
              clienteModalFechar.hide();
              setTimeout(function () {
                carregarConteudo("listarCliente");
                esconderProcessando();
              }, 2000);
              alert(data.message);
  
            } else {
              alert(data.message);
              console.error("Erro na requisição", error);
            }
          })
          .catch((error) => {
            console.error("Erro na requisição", error);
          });
      };
      formCategoria.addEventListener("submit", submitHandler);
    });
  }

  